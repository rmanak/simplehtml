<p><a href="Template.html">Home</a>
<a href="README.html">README</a>
<a href="format.html">HTML</a>
<a href="images.html">Images</a>
<a href="Contact.html">Contact</a>
<a href="Credit.html">Credit</a></p>
