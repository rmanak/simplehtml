<p>&copy; John Smith (2014) | More Text</p>
