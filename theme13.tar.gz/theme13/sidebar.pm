<p><a href="#contents_item_1">Features</a>&#8226;
<a href="#contents_item_7">Code Highlighting</a>&#8226;
<a href="#contents_item_4">Images</a>&#8226;
<a href="#contents_item_5">TOC</a>&#8226;
<a href="#contents_item_12">Download</a></p>
