<p>&copy; John Smith - More info</p>
