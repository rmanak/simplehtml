<p><a href="Template.html">Home<img src="img/home.svg" /></a>
<a href="README.html">About<img src="img/person.svg" /></a>
<a href="Contact.html">Contact<img src="img/envelope-closed.svg"></a>
<a href="download.html">Download[dl]</a></p>
